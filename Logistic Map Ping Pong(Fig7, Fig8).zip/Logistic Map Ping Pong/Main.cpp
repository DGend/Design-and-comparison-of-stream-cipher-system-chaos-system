#pragma warning(disable:4996)
#include <stdio.h>
#include <time.h>
#define NIST_COUNT_LEN 1000000000

#include <string.h>
#include <limits.h>

unsigned int double_to_bits(double val);
void encode(bool nowrite, double* x1, double r1, double* x2, double r2, int select_case);
void encode(bool nowrite, double* x1, double r1);
unsigned int cipher(bool nowrite, double* x1, double r1, double* x2, double r2, int select_case);
unsigned int cipher(bool nowrite, double* x1, double r1);
unsigned int logistic_map(double* x, double r);
bool LFSR127();

bool LFSR1[127] = {
	0,1,1,1,0,1,0,1,0,0,
	0,1,0,1,1,0,0,1,0,1,
	1,1,0,1,0,1,0,0,1,0,
	0,1,0,0,1,0,0,1,1,1,
	1,1,0,1,0,0,1,1,1,0,
	0,1,1,0,0,1,0,0,1,1,
	0,1,0,1,1,1,0,1,1,1,
	0,1,0,0,1,1,1,0,1,1,
	1,1,0,0,0,0,1,1,0,1,
	1,1,0,0,0,0,1,0,1,0,
	0,1,1,0,1,1,0,1,0,1,
	0,1,0,0,0,1,0,1,0,0,
	0,1,0,1,0,1,1 };

FILE *fa_result = fopen("fa_result.txt", "w");
FILE *fb_result = fopen("fb_result.txt", "w");
FILE *fc_result = fopen("fc_result.txt", "w");
FILE *fd_result = fopen("fd_result.txt", "w");
FILE *output_result = fopen("output_result.txt", "w");
FILE *total_result = fopen("total_result.txt", "w");
int printSplit = 0;
unsigned int count = 0;
char filename[] = "Logistic_PingPong";
unsigned int f1 = 0, f2 = 0, f3 = 0xACD445D5, f4 = 0x4B468F8D;	//�ǵ�� ��
unsigned int NIST_count = 0;

// 1. Ping Pong �� ��� ����
// 2. logistic map �Լ� ����
// 3. ���� Ŭ�� ������ � bit���� �� ���ΰ�?
// 4. ���� : �̹��� ��ȣȭ

void main() {
	clock_t start, end;
	float res;
	int menu = 0, select_case=0;
	// original value
	double x1 = 0.7861, x2 = 0.859227;
	// custum vlaue
	//double x1 = 0.00001, x2 = 0.00001;
	double r1 = 3.999, r2 = 3.999;

	while (true) {
		printf("1. Logistic map + Logistic map Ping Pong\n");
		printf("2. LFSR 127 + Logistic map Ping Pong\n");
		printf("�Է°� : ");
		scanf("%d", &menu);
		if (menu != 0)
			break;
	}

	switch (menu) {
	case 1:
		printf(" ===== �ǵ�� Ÿ�� ���� =====\n");
		printf("1. f3 = ((f1^f2)&f3) | (f1&f2), f4 = ((f1^f2)&f4) | f2\n");
		printf("2. f3 = (f3) ^ (f1&f2),         f4 = (f4) ^ (f1 | f2)\n");
		printf("�Է°� : ");
		while (getchar() != '\n');
		scanf("%d", &select_case);
		start = clock();
		encode(false, &x1, r1, &x2, r2, select_case);
		break;
	case 2:
		start = clock();
		encode(false, &x1, r1);
		break;
	}
	end = clock();
	printf("��������!\n");
	res = (float)(end - start) / CLOCKS_PER_SEC;
	printf("�� ���� �ҿ�� �ð� : %.3fs\n", res);
	
	while (getchar() != '\n');
	getchar();
	
	return;
}

void encode(bool nowrite, double* x1, double r1, double* x2, double r2, int select_case)
{
	int outbyte;
	int iter = 0, line = 0, ibyte = 0;
	FILE *op = fopen("Logi_pingpong.rnd", "w");
	if (!nowrite)
		fprintf(total_result, "\t\tA\tB\tC\tD\tOUTPUT\n");	

	for (iter = 0; iter < 19200; ++iter)
	{
		for (line = 0; line < 4; ++line)
		{
			outbyte = cipher(nowrite, x1, r1, x2, r2, select_case);
			if (!nowrite) 
				fprintf(op, "%08X", outbyte);			
		}
		if (!nowrite) 
			fprintf(op, "\n");
	}
	if (!nowrite) {
		fclose(op);
		fclose(fa_result);
		fclose(fb_result);
		fclose(fc_result);
		fclose(fd_result);
		fclose(output_result);
		fclose(total_result);
	}
}

unsigned int cipher(bool nowrite, double* x1, double r1, double* x2, double r2, int select_case)
{
	int printSplit = 0;
	unsigned int fa = 0, fb = 0, z = 0, temp = 0;
	unsigned int be_f3=f3, be_f4=f4;

	//Ŭ��ȸ�� ������
	fa = 2 * ((f1 >> 29) & 1) + ((f1 >> 3) & 1) + 1; // 2*Logistic1[5] + Logistic1[23] + 1
	fb = 2 * ((f2 >> 23) & 1) + ((f2 >> 7) & 1) + 1; // 2*Logistic2[7] + Logistic2[27] + 1

	for (int i = 0; i < fb; ++i)	
		f1 = logistic_map(x1, r1);	

	for (int j = 0; j < fa; ++j)	
		f2 = logistic_map(x2, r2);	

	z = f1^f2^f3^f4;

	++count;

	if (select_case == 1) {
		// case 1.
		f3 = ((f1 ^ f2) & f3) | (f1 & f2);
		f4 = ((f1 ^ f2) & f4) | f2;
	}
	else if (select_case == 2) {
		// case 2.
		f3 = (f3) ^ (f1 & f2);
		f4 = (f4) ^ (f1 | f2);
	}

	if (!nowrite) {
		temp = z;
		fprintf(fa_result, "%08X", f1);
		fprintf(fb_result, "%08X", f2);
		fprintf(fc_result, "%08X", f3);
		fprintf(fd_result, "%08X", f4);
		for (int i = 0; i < 32; ++i) {
			if (NIST_count < NIST_COUNT_LEN) {
				fprintf(output_result, "%01X", temp & 1);
				temp = temp >> 1;
			}			
		}
		fprintf(total_result, "%8d\t%08X\t%08X\t%08X\t%08X\t%08X\n", count, f1, f2, be_f3, be_f4, z);

		if (printSplit == 24) {
				fprintf(fa_result, "\n");
				fprintf(fb_result, "\n");
				fprintf(fc_result, "\n");
				fprintf(fd_result, "\n");
			if (NIST_count < NIST_COUNT_LEN)
				fprintf(output_result, "\n");
			printSplit = 0;
		}
		else
			++printSplit;
	}
	NIST_count = NIST_count + 32;
	return z;
}

void encode(bool nowrite, double* x1, double r1)
{
	int outbyte;
	int iter = 0, line = 0, ibyte = 0;
	FILE *op = fopen("Logi_LFSR_pingpong.rnd", "w");
	if (!nowrite) 
		fprintf(total_result, "\t\tA\tB\tC\tD\tOUTPUT\n");
	
	for (iter = 0; iter < 19200; ++iter)
	{
		for (line = 0; line < 16; ++line)
		{
			outbyte = 0;
			for (ibyte = 0; ibyte < 8; ++ibyte)
			{
				outbyte = (outbyte * 2) ^ cipher(nowrite, x1, r1);
			}
			if (!nowrite) 
				fprintf(op, "%02X", outbyte);
		}
		if (!nowrite) 
			fprintf(op, "\n");
	}
	if (!nowrite) {
		fclose(op);
		fclose(fa_result);
		fclose(fb_result);
		fclose(fc_result);
		fclose(fd_result);
		fclose(output_result);
		fclose(total_result);
	}
}

/*
Logistic map(32bit) + LFSR(1bit)
f1	:32bit
f2	: 1bit -> 32bit
*/
unsigned int cipher(bool nowrite, double* x1, double r1)
{
	int printSplit = 0;
	unsigned int fa = 0, fb = 0, z = 0;

	//Ŭ��ȸ�� ������
	//fa = ((f1 >> 26) & 1) + ((f1 >> 24) & 1) + ((f1 >> 8) & 1) + ((f1 >> 3) & 1) + 1; // Logistic1[5] + Logistic1[7] + Logistic1[23] + Logistic1[29] + 1
	fa = 2 * ((f1 >> 26) & 1) + ((f1 >> 8) & 1) + 1; // Logistic1[5] + Logistic1[23]
	fb = 2 * LFSR1[42] + LFSR1[85] + 1;

	for (int i = 0; i < fb; ++i)
		f1 = logistic_map(x1, r1);
	
	// 32�� shift�ϱ� ������ �������� �ʱ�ȭ�� �ʿ䰡 ����.
	for (int j = 0; j < 32; ++j) {
		f2 = (f2 << 1);

		for (int k = 0; k < fa; ++k)
			f2 = f2 + LFSR127();
	}
		
	z = f1^f2^f3^f4;

	++count;
	if (!nowrite) {
		fprintf(fa_result, "%01X", f1);
		fprintf(fb_result, "%01X", f2);
		fprintf(fc_result, "%01X", f3);
		fprintf(fd_result, "%01X", f4);
		if (NIST_count< NIST_COUNT_LEN)
			fprintf(output_result, "%1X", z);
		fprintf(total_result, "%8d\t%02X\t%02X\t%02X\t%02X\t%02X\n", count, f1, f2, f3, f4, z);
	}
	// case 1.
	f3 = ((f1^f2)&f3) | (f1 & f2);
	f4 = ((f1^f2)&f4) | f1;

	// case 2.
	//f3 = (f3) | (f1&f2);
	//f4 = ((f1^f2)&f4) | f2;

	// case 3.
	//f3 = (f3) | (f1&f2);
	//f4 = (f4) | f2;

	if (!nowrite) {
		if (printSplit == 24) {
			fprintf(fa_result, "\n");
			fprintf(fb_result, "\n");
			fprintf(fc_result, "\n");
			fprintf(fd_result, "\n");
			if (NIST_count< NIST_COUNT_LEN)
				fprintf(output_result, "\n");
			printSplit = 0;
		}
		else {
			++printSplit;
		}
	}
	++NIST_count;
	return z;
}

/**
* @brief ������ƽ�� �Լ�
*
* @param x ������ ���� �Ҽ���
* @param r ������ƽ��
* @return unsigned int ������(32bit)
*/
unsigned int logistic_map(double* x, double r) {
	// ī���� �ý��� ������	
	unsigned int result = 0;
	*x = r * *x * (1 - *x);

	result = double_to_bits(*x);

	/*uTemp1 = *(unsigned *)x;
	for (int k = 8, j = 0; k > 4; --k) {
		for (j = k * 8 - 1; j > (k - 1) * 8; --j)
		{
			result = result << 1;
			result = result ^ (uTemp1 & (1 << j) ? 1 : 0);
		}
	}*/

	//printf("\n");	
	//for (unsigned int i = 1 << 31; i > 0; i = i >> 1)
	//	(result & i) ? printf("1") : printf("0");
	//printf(" = %u\n",result);

	return result;
}

unsigned int double_to_bits(double val)
{
	unsigned idx;
	unsigned char* ptr = (unsigned char*)& val;
	unsigned int result = 0;

	/*for (idx = 64; idx>0; idx--) {
		putc(
			(ptr[idx / CHAR_BIT] & (1u << (idx % CHAR_BIT)))
			? '1'
			: '0'
			, stdout
		);
	}*/
	for (idx = 32; idx > 0; idx--) {
		/*putc(
			(ptr[idx / CHAR_BIT] & (1u << (idx % CHAR_BIT)))
			? '1'; result = (result << 1) + 1
			: '0'
			, stdout
		);*/
		(ptr[idx / CHAR_BIT] & (1u << (idx % CHAR_BIT)))
			? result = (result << 1) + 1
			: result = (result << 1) + 0;
	}

	/*printf("\n");
	for (int i = 0; i < 32; i++)
		printf(" ");
	for (unsigned int i = 1 << 31; i > 0; i = i >> 1)
		(result & i) ? printf("1") : printf("0");
	printf(" = %u\n",result);*/

	return result;
}

//Galois_LFSR
bool LFSR127()
{
	int len = 127;
	// 31TAP
	int xor[] = { 127,109,91,84,73,67,66,63,56,55,52,48,45,42,41,37,34,30,27,23,21,20,19,16,13,12,7,6,2,1 };
	bool result = LFSR1[len-1];

	for (int i = len - 1; i > 0; --i) {
		LFSR1[i] = LFSR1[i - 1];		
	}

	if (result) {
		for (int j = 0, MAX = sizeof(xor) / sizeof(xor[0]); j < MAX; ++j) {
			LFSR1[xor[j] - 1] = !LFSR1[xor[j] - 1];
		}
	}

	LFSR1[0] = result;
	return result;
}